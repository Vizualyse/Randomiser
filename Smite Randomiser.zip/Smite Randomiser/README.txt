To add rules, click on the modify rules button, type the rule into the entry box and press enter.

The app retrieves its god list from the Smite Wiki, so it will stay up to date, but also requires an internet connection.